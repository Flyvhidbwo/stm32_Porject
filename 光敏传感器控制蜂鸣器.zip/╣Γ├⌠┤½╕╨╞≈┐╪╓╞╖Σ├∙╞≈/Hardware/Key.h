#ifndef __KEY_H
#define __KEY_H

void key_Init(void);
uint8_t Key_GetNum(void);

#endif